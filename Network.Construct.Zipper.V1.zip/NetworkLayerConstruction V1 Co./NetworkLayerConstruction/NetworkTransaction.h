//
//  NetworkTransaction.h
//  NetworkLayerConstruction
//
//  Created by Jerry Ren on 2/28/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double NetworkTransactionVersionNumber;

FOUNDATION_EXPORT const unsigned char NetworkTransactionVersionString[];
   
